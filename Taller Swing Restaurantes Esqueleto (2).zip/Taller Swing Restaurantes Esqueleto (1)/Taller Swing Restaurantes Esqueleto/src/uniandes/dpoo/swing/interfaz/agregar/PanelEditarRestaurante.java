package uniandes.dpoo.swing.interfaz.agregar;

import java.awt.GridLayout;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class PanelEditarRestaurante extends JPanel
{
    private JTextField txtNombre;

    private JComboBox<String> cbbCalificacion;

    private JComboBox<String> cbbVisitado;

    public PanelEditarRestaurante( )
    {
        setLayout( new GridLayout( 3, 2 ) );

        JLabel lblNombre = new JLabel( "Nombre" );
        txtNombre = new JTextField( );

        JLabel lblCalificacion = new JLabel( "Calificación" );
        cbbCalificacion = new JComboBox<String>( );
        cbbCalificacion.addItem( "1" );
        cbbCalificacion.addItem( "2" );
        cbbCalificacion.addItem( "3" );
        cbbCalificacion.addItem( "4" );
        cbbCalificacion.addItem( "5" );

        JLabel lblVisitado = new JLabel( "Visitado" );
        cbbVisitado = new JComboBox<String>( );
        cbbVisitado.addItem( "Sí" );
        cbbVisitado.addItem( "No" );

        add( lblNombre );
        add( txtNombre );
        add( lblCalificacion );
        add( cbbCalificacion );
        add( lblVisitado );
        add( cbbVisitado );
    }

    public boolean fueVisitado( )
    {
        return cbbVisitado.getSelectedItem( ).equals( "Sí" );
    }

    public int darCalificacion( )
    {
        return Integer.parseInt( ( String )cbbCalificacion.getSelectedItem( ) );
    }

    public String darNombre( )
    {
        return txtNombre.getText( );
    }

    public boolean getVisitado( )
    {
        // TODO completar
        return false;
    }

    /**
     * Indica la calificación marcada en el selector
     * @return
     */
    public int getCalificacion( )
    {
        String calif = ( String )cbbCalificacion.getSelectedItem( );
        return Integer.parseInt( calif );
    }

    /**
     * Indica el nombre digitado para el restaurante
     * @return
     */
    public String getNombre( )
    {
        // TODO completar
        return "";
    }
}
