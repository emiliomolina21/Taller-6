package uniandes.dpoo.swing.interfaz.agregar;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import uniandes.dpoo.swing.interfaz.principal.VentanaPrincipal;

@SuppressWarnings("serial")
public class VentanaAgregarRestaurante extends JFrame
{
    private PanelEditarRestaurante panelDetalles;

    private PanelBotonesAgregar panelBotones;

    private PanelMapaAgregar panelMapa;

    private VentanaPrincipal ventanaPrincipal;

    public VentanaAgregarRestaurante( VentanaPrincipal principal )
    {
        this.ventanaPrincipal = principal;
        setLayout( new BorderLayout( ) );

        panelMapa = new PanelMapaAgregar( );
        add( panelMapa, BorderLayout.CENTER );

        panelDetalles = new PanelEditarRestaurante( );
        panelBotones = new PanelBotonesAgregar( this );

        JPanel panelSur = new JPanel( new BorderLayout( ) );
        panelSur.add( panelDetalles, BorderLayout.CENTER );
        panelSur.add( panelBotones, BorderLayout.SOUTH );

        add( panelSur, BorderLayout.SOUTH );

        pack( );
        setLocationRelativeTo( null );
        setDefaultCloseOperation( DISPOSE_ON_CLOSE );
        setResizable( false );
    }

    public void agregarRestaurante( )
    {
        String nombre = panelDetalles.darNombre( );
        int calificacion = panelDetalles.darCalificacion( );
        int x = panelMapa.getX( );
        int y = panelMapa.getY( );
        boolean visitado = panelDetalles.fueVisitado( );

        ventanaPrincipal.agregarRestaurante( nombre, calificacion, x, y, visitado );

        dispose( );
    }

    public void cerrarVentana( )
    {
        dispose( );
    }
}